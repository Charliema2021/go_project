package main

import "fmt"
func main(){
	var a int
	result = 10 + a++

	fmt.println("reslult=",result)

}